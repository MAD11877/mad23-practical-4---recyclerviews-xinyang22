package sg.edu.np.mad.week4recycleview;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MyCustomViewHolder extends RecyclerView.ViewHolder
{
    TextView txt;

    ImageView image;

    public MyCustomViewHolder(View itemView)
    {
        super(itemView);

        txt = itemView.findViewById(R.id.textView);

        image = itemView.findViewById(R.id.imageview);
    }
}
