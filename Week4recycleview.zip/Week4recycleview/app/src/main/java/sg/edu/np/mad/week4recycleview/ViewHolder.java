package sg.edu.np.mad.week4recycleview;
import android.view.View;
import android.widget.TextView;
import android.util.Log;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder{
    String TAG = "View Holder";

    TextView txt;

    public ViewHolder(View itemView)
    {
        super(itemView);

        txt = itemView.findViewById(R.id.textView);

        Log.i(TAG, "ViewHolder linked.");
    }
}