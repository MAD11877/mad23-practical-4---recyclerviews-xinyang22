package sg.edu.np.mad.week4recycleview;

public class MyObject
{
    private int myImageID;

    private String myText;

    public MyObject()
    {

    }

    public int getMyImageID() {
        return myImageID;
    }

    public void setMyImageID(int myImageID) {
        this.myImageID = myImageID;
    }

    public String getMyText() {
        return myText;
    }

    public void setMyText(String myText) {
        this.myText = myText;
    }
}

