package sg.edu.np.mad.week4recycleview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyCustomAdaptor extends RecyclerView.Adapter<MyCustomViewHolder>
{
    private ArrayList<MyObject> myObjects;

    public MyCustomAdaptor(ArrayList<MyObject> myObjects)
    {
        this.myObjects = myObjects;
    }

    public MyCustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_layout, parent, false);

        MyCustomViewHolder holder = new MyCustomViewHolder(view);

        return holder;
    }

    public void onBindViewHolder(MyCustomViewHolder holder, int position)
    {
        MyObject listItems = myObjects.get(position);

        holder.txt.setText(listItems.getMyText());

        holder.image.setImageResource(listItems.getMyImageID());
    }

    public int getItemCount()
    {
        return myObjects.size();
    }
}

