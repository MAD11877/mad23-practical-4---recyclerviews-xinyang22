package sg.edu.np.mad.week4recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //ArrayList<String> data=new ArrayList<String>();
    ArrayList<MyObject> myObjects_List = new ArrayList<>();
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*
        for(int i=0; i<100; i++){
            data.add(String.valueOf(i));
        }

        RecyclerView recyclerView=findViewById(R.id.recyclerview);
        AdapterDemo mAdapter = new AdapterDemo(data);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(recyclerView.getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        */

        for(int i=0; i<100; i++)
        {
            MyObject obj=new MyObject();
            obj.setMyImageID(R.drawable.dog);
            obj.setMyText(String.valueOf(i));

            myObjects_List.add(obj);
        }

        RecyclerView recyclerView= findViewById(R.id.recyclerview);
        MyCustomAdaptor myCustomAdaptor = new MyCustomAdaptor(myObjects_List);

        LinearLayoutManager myLayoutManager = new LinearLayoutManager(this);

        recyclerView.setLayoutManager(myLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(myCustomAdaptor);

    }
}